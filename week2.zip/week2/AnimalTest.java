class Animal {

   // Properties of the class...
   public int     numberOfLegs;
   public boolean hasWings;

   // Constructor of the class...
   public Animal() {
      numberOfLegs = 4;
      hasWings = false;
   }

   // Methods of the class...
   public void talk() {
      System.out.println("Hello");
   }
}

class Bird extends Animal {

   // Properties of the class...
   public boolean canFly;

   // Constructor of the class...
   public Bird() {
      numberOfLegs = 2;
      hasWings = true;
      canFly = true;
   }

   // Methods of the class...
   public void fly() {
      System.out.println("flap flap");
   }
}

class Eagle extends Bird {

   // Properties of the class...
   private int numberOfKills;

   // Constructor of the class...
   Eagle() {
      numberOfKills = 0;
   }

   // Methods of the class...
   public void attack() {
      numberOfKills++;
   }
}

class AnimalTest {

   // The main method is the point of entry into the program...
   public static void main(String[] args) {

      Animal a = new Animal();
      System.out.println(a.numberOfLegs);
      System.out.println(a.hasWings);
      a.talk();
      // a.fly(); fly is een method van bird.

      Bird b = new Bird();
      System.out.println(b.numberOfLegs);
      System.out.println(b.hasWings);
      System.out.println(b.canFly);
      // System.out.println(b.numberOfKills);   b is een bird en numberOFKills is een method van Eagle
      b.talk();
      // b.attack();    b is een bird en attack is een method van Eagle

      Eagle e = new Eagle();
      // System.out.println(e.numberOfKills);   numberOfKills is private dus kan buiten de class niet worden gebruikt
      System.out.println(e.numberOfLegs);
      System.out.println(e.hasWings);
      e.talk();
      e.attack();

      a = b;
      a.talk();
      // a.fly();

      // b = a;
      b.talk();
      b.fly();
   }
}


/**
 * vraag 1d: Eagle maakt gebruik van de Bird class, daar wordt numberOfLegs op 2 gezet.
 * vraag 1e: a.fly() geeft een error, a was een animal en kan niet bij de Bird methods.
 * vraag 1f: b = a geeft een error, b is een subclass van animal dus kan animal worde.
 **/