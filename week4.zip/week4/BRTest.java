/* Need to import java.io package to use the BufferedReader and
	 InputStreamReader.
*/
import java.io.*;

public class BRTest {

  // properties
  private int calls;
  private int successfulCalls;
  private int totalReturned;
  private int[] excepCounts;
  private int number;
  private boolean succes;

  // methods
  public void callIt() {
    calls += 1;
    succes = true;

    try {
      number = BadRandom.randVal();
    } catch (ArithmeticException a) {
      System.err.println("IOException exception occured " + a.getMessage());
      excepCounts[0] += 1;
      succes = false;
    } catch (NullPointerException n) {
      System.err.println("NumberFormatException exception occured " + n.getMessage());
      excepCounts[1] += 1;
      succes = false;
    } catch (ArrayIndexOutOfBoundsException i) {
      System.err.println("IOException exception occured " + i.getMessage());
      excepCounts[2] += 1;
      succes = false;
    } catch (ClassCastException c) {
      System.err.println("NumberFormatException exception occured " + c.getMessage());
      excepCounts[3] += 1;
      succes = false;
    } catch (NegativeArraySizeException s) {
      System.err.println("NumberFormatException exception occured " + s.getMessage());
      excepCounts[4] += 1;
      succes = false;
    }
    if (succes == true) {
      successfulCalls += 1;
    }
    totalReturned += number;
  }
  public void resetCounts() {
    calls = 0;
    successfulCalls = 0;
    totalReturned = 0;
    excepCounts = new int[]{0,0,0,0,0};
  }
  public void nRandInts(int n) {
    if (n < 1) {
      System.err.println("n must be a positive integer");
    }
    else {
      while (successfulCalls < n) {
        callIt();
      }
    }
  }
  public void writeData() {
    System.out.println("Number of calls: " + calls);
    System.out.println("Successful calls: " + successfulCalls);
    System.out.println("Total returned: " + totalReturned);

    System.out.println("Percentage Arithmetic Exceptions: " + 100*excepCounts[0]/calls);
    System.out.println("Percentage Null Pointer Exceptions: " + 100*excepCounts[1]/calls);
    System.out.println("Percentage Array Index Exceptions: " + 100*excepCounts[2]/calls);
    System.out.println("Percentage Class Cast Exceptions: " + 100*excepCounts[3]/calls);
    System.out.println("Percentage Negative Array Exceptions: " + 100*excepCounts[4]/calls);

    System.out.println("Percentage of successful calls: " + 100*successfulCalls/calls);
  }

  public static void main(String[] args) {
    BRTest me = new BRTest();
    me.resetCounts();
    me.nRandInts(30);
    me.writeData(); }
}
